VERTEX VISUALS 1.0 — Android APK project
========================================

Что сейчас есть:
- Android-приложение на Kotlin + WebView.
- Чёрно-изумрудный интерфейс VERTEX, вкладки PvP, FPS, HUD, Packs, Versions.
- GitHub Actions workflow автоматически собирает debug APK.

Важно: это пока оболочка/интерфейс, НЕ полноценный Minecraft Java launcher.
Загрузка и запуск Minecraft, Fabric, Microsoft OAuth и реальная установка паков ещё не реализованы.
Настройки и карточки, помеченные DEMO/превью, не меняют сам Minecraft.

Сборка прямо с телефона (без ПК):
1. Создай репозиторий на GitHub и загрузи туда содержимое этого ZIP (именно файлы внутри ZIP, не сам ZIP).
2. Открой репозиторий → вкладка Actions.
3. Выбери workflow “Build VERTEX Android APK” → Run workflow. Если GitHub попросит, разреши Actions.
4. Дождись зелёной галочки завершения сборки.
5. Внизу страницы запуска открой Artifacts → VERTEX-Launcher-debug-apk и скачай ZIP с APK.
6. Распакуй ZIP и установи app-debug.apk на Android.

Если сборка красная/ошибка — пришли скриншот ошибки. Не публикуй пароли, токены или секреты.

Пакет приложения: com.vertex.launcher (namespace исходного Kotlin оставлен com.evo.launcher для совместимости проекта).
